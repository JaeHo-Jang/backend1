package a0814.entity;

public enum TradeType {
    입급, 출금, 생성;
}
